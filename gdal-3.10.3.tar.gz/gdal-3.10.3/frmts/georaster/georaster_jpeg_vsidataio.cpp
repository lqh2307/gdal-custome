#include "georaster_jpeg_vsidataio.h"

#include "../jpeg/vsidataio.cpp"

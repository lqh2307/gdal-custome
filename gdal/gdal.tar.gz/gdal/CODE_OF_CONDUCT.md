Code of Conduct
===============

See [the GDAL Code of Conduct](https://gdal.org/community/code_of_conduct.html).

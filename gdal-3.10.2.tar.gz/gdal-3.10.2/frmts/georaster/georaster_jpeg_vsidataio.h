#ifndef GEORASTER_JPEG_VSIDATAIO_H_INCLUDED
#define GEORASTER_JPEG_VSIDATAIO_H_INCLUDED

#define jpeg_vsiio_src GEOR_jpeg_vsiio_src
#define jpeg_vsiio_dest GEOR_jpeg_vsiio_dest
#include "../jpeg/vsidataio.h"

#endif /* GEORASTER_JPEG_VSIDATAIO_H_INCLUDED */

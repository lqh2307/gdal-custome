
# INPUT OPTIONS

-F, \--input-format=FORMAT
:   The format of the input file(s). Can be used to set the input format if it
    can't be autodetected from the file name(s). This will set the format for
    all input files, there is no way to set the format for some input files
    only. See **osmium-file-formats**(5) or the libosmium manual for details.

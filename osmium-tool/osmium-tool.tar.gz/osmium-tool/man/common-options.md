
# COMMON OPTIONS

-h, \--help
:   Show usage help.

-v, \--verbose
:   Set verbose mode. The program will output information about what it is
    doing to STDERR.
